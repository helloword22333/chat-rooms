﻿namespace ChatRoom.Server
{
    partial class ServerForm
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        public System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox_ONLINE_COUNT = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox_SERVER_PORT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_SERVER_IP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_MSG = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button1);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_ONLINE_COUNT);
            this.splitContainer1.Panel1.Controls.Add(this.label3);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_SERVER_PORT);
            this.splitContainer1.Panel1.Controls.Add(this.label2);
            this.splitContainer1.Panel1.Controls.Add(this.textBox_SERVER_IP);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            this.splitContainer1.Panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.splitContainer1_Panel1_Paint);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.textBox_MSG);
            this.splitContainer1.Size = new System.Drawing.Size(549, 416);
            this.splitContainer1.SplitterDistance = 147;
            this.splitContainer1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(35, 107);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(109, 37);
            this.button1.TabIndex = 6;
            this.button1.Text = "刷新在线人数";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox_ONLINE_COUNT
            // 
            this.textBox_ONLINE_COUNT.Location = new System.Drawing.Point(97, 177);
            this.textBox_ONLINE_COUNT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_ONLINE_COUNT.Name = "textBox_ONLINE_COUNT";
            this.textBox_ONLINE_COUNT.ReadOnly = true;
            this.textBox_ONLINE_COUNT.Size = new System.Drawing.Size(41, 22);
            this.textBox_ONLINE_COUNT.TabIndex = 5;
            this.textBox_ONLINE_COUNT.Text = "0";
            this.textBox_ONLINE_COUNT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox_ONLINE_COUNT.TextChanged += new System.EventHandler(this.textBox_ONLINE_COUNT_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("字魂110号-武林江湖体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(41, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "当前在线人数";
            // 
            // textBox_SERVER_PORT
            // 
            this.textBox_SERVER_PORT.Location = new System.Drawing.Point(44, 69);
            this.textBox_SERVER_PORT.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_SERVER_PORT.Name = "textBox_SERVER_PORT";
            this.textBox_SERVER_PORT.ReadOnly = true;
            this.textBox_SERVER_PORT.Size = new System.Drawing.Size(89, 22);
            this.textBox_SERVER_PORT.TabIndex = 3;
            this.textBox_SERVER_PORT.Text = "9000";
            this.textBox_SERVER_PORT.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "端口：";
            // 
            // textBox_SERVER_IP
            // 
            this.textBox_SERVER_IP.Location = new System.Drawing.Point(10, 31);
            this.textBox_SERVER_IP.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_SERVER_IP.Name = "textBox_SERVER_IP";
            this.textBox_SERVER_IP.ReadOnly = true;
            this.textBox_SERVER_IP.Size = new System.Drawing.Size(123, 22);
            this.textBox_SERVER_IP.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "当前IP地址：";
            // 
            // textBox_MSG
            // 
            this.textBox_MSG.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox_MSG.Location = new System.Drawing.Point(0, 0);
            this.textBox_MSG.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.textBox_MSG.Multiline = true;
            this.textBox_MSG.Name = "textBox_MSG";
            this.textBox_MSG.ReadOnly = true;
            this.textBox_MSG.Size = new System.Drawing.Size(398, 416);
            this.textBox_MSG.TabIndex = 0;
            this.textBox_MSG.TextChanged += new System.EventHandler(this.textBox_MSG_TextChanged);
            // 
            // ServerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(549, 416);
            this.Controls.Add(this.splitContainer1);
            this.Font = new System.Drawing.Font("字魂103号-海棠手书", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "ServerForm";
            this.Text = "Form1";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.SplitContainer splitContainer1;
        public System.Windows.Forms.TextBox textBox_MSG;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.TextBox textBox_SERVER_IP;
        public System.Windows.Forms.TextBox textBox_SERVER_PORT;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox textBox_ONLINE_COUNT;
        public System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}

